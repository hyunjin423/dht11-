<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
	<tr>
		<td bgcolor="#425163" height="25"><div align='center'><img src="image/btm_copy.gif"></div></td>
	</tr>
</table>